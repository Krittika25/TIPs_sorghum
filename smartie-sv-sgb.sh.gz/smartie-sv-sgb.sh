#!/bin/bash

set -eu

TMPDIR="$(mktemp -dp "${TMPDIR:-/tmp}" builder.XXXX)"
export TMPDIR

set -eux
umask 0022
IFS=$'\n'


########################################################################

BASEDIR="${HOME}/sw"

URL="https://github.com/sgblanch/smartie-sv.git"
PACKAGE="$(basename "${URL}" .git)"


########################################################################

git clone -q --recursive "${URL}" "${TMPDIR}/${PACKAGE}"
git -C "${TMPDIR}/${PACKAGE}" checkout origin/update-blasr -b update-blasr --recurse-submodules

VERSION="$(git --git-dir="${TMPDIR}/${PACKAGE}/.git" describe --tags 2>/dev/null || git --git-dir="${TMPDIR}/${PACKAGE}/.git" rev-parse --short HEAD)"
DESTDIR="${BASEDIR}/packages/${PACKAGE}/${VERSION}"


########################################################################

cd "${TMPDIR}/${PACKAGE}"

make -j4
install -m 0755 -d ${DESTDIR}
rsync -aP bin example pipeline ${DESTDIR}


########################################################################

install -m 0755 -d ${BASEDIR}/modules/${PACKAGE}

cat > ${BASEDIR}/modules/${PACKAGE}/${VERSION} <<EOF
#%Module1.0#############################################################
##
## ${PACKAGE} modulefile
##
set package      "${PACKAGE}"
set version      "${VERSION}"
set description  "align query contigs against a reference genome and call structural variants"
set url          "https://github.com/zeeev/smartie-sv"
set license      "unknown"

# Group-wide modules
set base        ${BASEDIR}/packages/\$package/\$version

########################################################################

setenv        SMARTIE_SV          \$base

# Add executables and man pages to appropriate search paths
prepend-path  PATH                \$base/bin

########################################################################

module-whatis "\$description"

proc ModulesHelp { } {
    global description license package url version

    puts stderr "\$package - \$description"
    puts stderr "\tURL      \$url"
    puts stderr "\tLicense  \$license"
    puts stderr "\tVersion  \$version\n"
}
EOF
